MIMOPY ANDROID BUILD (DEBUG APK)

Ini adalah project Android pembungkus WebView untuk HTML Mimopy dari ZIP yang diberikan. APK belum dikompilasi di perangkat ini karena Android SDK/Gradle tidak tersedia di lingkungan kerja. Workflow GitHub Actions disediakan untuk mengompilasinya secara cloud.

CARA BUILD DARI HP:
1. Ekstrak ZIP ini.
2. Upload seluruh isi folder ke repository GitHub baru (branch main). Pastikan file .github/workflows/build-apk.yml ikut ter-upload.
3. Buka repository > Actions > Build Mimopy APK > Run workflow. Jika workflow belum terlihat, buka tab Actions dan aktifkan Actions untuk repository.
4. Tunggu hingga selesai, buka run yang berhasil, lalu bagian Artifacts > Mimopy-debug-APK untuk mengunduh ZIP berisi app-debug.apk.
5. Ekstrak ZIP artifact dan instal app-debug.apk. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

CATATAN:
- Ini APK debug untuk uji coba, bukan release APK bertanda tangan untuk distribusi publik.
- HTML dimuat dari asset lokal. Akses internet diperlukan untuk layanan Supabase.
- Link web eksternal dibuka di browser perangkat.
- Mekanisme satu perangkat tetap memakai ID browser/localStorage sesuai HTML sumber; ini bukan proteksi perangkat keras yang anti-bypass.
- SQL one-device-lock.sql tidak disertakan ke dalam APK dan harus dipasang terpisah di Supabase sebelum menguji fitur device lock.
- Jangan masukkan service-role key atau secret PASSWORD_VAULT_KEY ke file frontend atau repository.
